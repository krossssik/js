import { PersonCard } from "./person-card";

export default PersonCard;
