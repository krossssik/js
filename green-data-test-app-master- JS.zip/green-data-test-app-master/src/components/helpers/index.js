import { withData } from "./get-data";

export default withData;