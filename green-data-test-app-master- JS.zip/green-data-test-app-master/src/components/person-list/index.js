import { PersonList } from "./person.list";

export default PersonList;