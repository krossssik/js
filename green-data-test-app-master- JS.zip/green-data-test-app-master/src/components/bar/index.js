import { Bar } from "./bar.jsx";

export default Bar;
